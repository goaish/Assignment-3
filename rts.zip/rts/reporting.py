# reporting.py

"""
Generates reports based on the evaluation results of LLM tests.
Provides a summary of passed/failed tests and detailed information for failures.
"""

from typing import List
from evaluation_engine import EvaluationResult
import os
from datetime import datetime

def generate_report(results: List[EvaluationResult], results_dir: str, model_name: str = "Unknown Model") -> str:
    """
    Generates a text-based report from a list of evaluation results.

    Args:
        results (List[EvaluationResult]): A list of EvaluationResult objects.
        results_dir (str): The directory where the report file should be saved.
        model_name (str): The name of the LLM model for which the report is being generated.

    Returns:
        str: The path to the generated report file.
    """
    total_tests = len(results)
    passed_tests = sum(1 for r in results if r.passed)
    failed_tests = total_tests - passed_tests

    report_content = []
    report_content.append("--- LLM Regression Test Report ---")
    report_content.append(f"Model Tested: {model_name}")
    report_content.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_content.append(f"Total Test Cases: {total_tests}")
    report_content.append(f"Passed: {passed_tests}")
    report_content.append(f"Failed: {failed_tests}")
    report_content.append("-" * 30)

    if failed_tests > 0:
        report_content.append("\n--- Failed Test Cases ---")
        for result in results:
            if not result.passed:
                report_content.append(f"\nTest Case ID: {result.test_case_id}")
                report_content.append(f"  Status: FAILED")
                report_content.append(f"  Reason: {result.message}")
                if result.details:
                    for key, value in result.details.items():
                        report_content.append(f"  Detail - {key}: {value}")
                report_content.append("-" * 20)
    else:
        report_content.append("\nAll tests passed successfully for this model!")

    # Include model name in the filename to distinguish reports
    report_filename = f"llm_regression_report_{model_name.replace(' ', '_').lower()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    report_filepath = os.path.join(results_dir, report_filename)

    try:
        with open(report_filepath, 'w', encoding='utf-8') as f:
            f.write("\n".join(report_content))
        print(f"\nReport generated successfully for {model_name}: {report_filepath}")
    except IOError as e:
        print(f"Error writing report for {model_name} to file {report_filepath}: {e}")
        report_filepath = "" # Indicate failure to save

    return report_filepath

if __name__ == '__main__':
    # Example usage:
    # This block demonstrates how to use the generate_report function.
    # In a real scenario, 'results' would come from the main test runner.
    from evaluation_engine import EvaluationResult # Import for type hinting

    # Create a dummy results directory if it doesn't exist
    dummy_results_dir = "dummy_reports"
    os.makedirs(dummy_results_dir, exist_ok=True)

    dummy_results = [
        EvaluationResult("TC001", True, "Passed: Normalized match."),
        EvaluationResult("TC002", False, "Failed: Output too short.", {"expected": "A longer poem...", "actual": "Short poem."}),
        EvaluationResult("TC003", True, "Passed: Normalized match."),
        EvaluationResult("TC004", False, "Failed: Potentially unsafe content detected.", {"safety_check": "keyword 'illegal' detected"})
    ]

    print("--- Generating example report ---")
    # Provide a model name for the example report
    report_file = generate_report(dummy_results, dummy_results_dir, model_name="Example Model A")
    if report_file:
        with open(report_file, 'r', encoding='utf-8') as f:
            print("\n--- Report Content ---")
            print(f.read())
            print("--- End Report Content ---")
