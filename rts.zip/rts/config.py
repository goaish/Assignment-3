# config.py

"""
Configuration settings for the LLM Regression Testing System.
This file centralizes paths, model names, and API keys for easy management.
"""

import os

# --- File Paths ---
# Path to the JSON file containing test cases.
TEST_CASES_FILE = 'test_cases.json'

# Directory where test results and reports will be saved.
RESULTS_DIR = 'test_results'
os.makedirs(RESULTS_DIR, exist_ok=True) # Ensure the directory exists

# --- LLM Settings ---
# List of LLM models to be used for testing. Each dictionary represents a model.
# 'name': A unique identifier for the model (e.g., 'Gemini Flash', 'Llama 2 7B Chat').
# 'model_id': The actual model identifier used in the API call or local server.
#             For open-source models, this might be a Hugging Face model ID,
#             or a local endpoint identifier (e.g., 'llama2' if using Ollama).
# 'api_key': The API key for this specific model. Can be empty if not required
#            (e.g., for locally served open-source models) or if handled by environment.
#            For Canvas, it's left empty for Google models as Canvas injects it.
# 'api_endpoint': (Optional) The base URL for the model's API if different from default.
#                 Useful for self-hosted or different inference APIs.
LLM_MODELS_CONFIGS = [
    {
        "name": "Gemini Flash",
        "model_id": "gemini-2.0-flash",
        "api_key": "" # Canvas will inject this at runtime for Google models
    },
    {
        "name": "Llama 2 7B Chat (Conceptual)",
        "model_id": "meta-llama/Llama-2-7b-chat-hf", # Example Hugging Face model ID
        "api_key": "YOUR_HUGGINGFACE_API_KEY_HERE", # Replace with actual key if using HF Inference API
        "api_endpoint": "https://api-inference.huggingface.co/models/" # Example HF Inference API endpoint
    },
    {
        "name": "Mistral 7B Instruct (Conceptual)",
        "model_id": "mistralai/Mistral-7B-Instruct-v0.2", # Example Hugging Face model ID
        "api_key": "YOUR_HUGGINGFACE_API_KEY_HERE", # Replace with actual key if using HF Inference API
        "api_endpoint": "https://api-inference.huggingface.co/models/" # Example HF Inference API endpoint
    },
    # Add more open-source or proprietary models here as needed
    # For a locally served model (e.g., via Ollama or vLLM):
    # {
    #     "name": "Local Llama3",
    #     "model_id": "llama3", # Model name as recognized by Ollama
    #     "api_key": "", # No API key needed for local models
    #     "api_endpoint": "http://localhost:11434/api/generate" # Ollama local API endpoint
    # },
]

# --- Evaluation Settings ---
# Threshold for semantic similarity (if a more advanced evaluation is implemented).
# A higher value means responses must be more similar to be considered a pass.
SEMANTIC_SIMILARITY_THRESHOLD = 0.75 # Example value
