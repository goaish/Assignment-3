# llm_interface.py

"""
Provides an interface to interact with various LLM (Large Language Model) APIs.
This module handles the API calls to the specified LLM,
abstracting the communication details from the rest of the system.
It is designed to be adaptable for different LLM providers (e.g., Google, Hugging Face, local servers).
"""

import json
import time 
import random 

class LLMInterface:
    """
    Handles communication with a specific LLM model, adapting to different API endpoints.
    """
    def __init__(self, model_id: str, api_key: str = "", api_endpoint: str = None):
        """
        Initializes the LLMInterface with the model ID, API key, and an optional custom API endpoint.

        Args:
            model_id (str): The ID of the LLM model to interact with (e.g., 'gemini-2.0-flash', 'meta-llama/Llama-2-7b-chat-hf').
            api_key (str): The API key for authentication with the LLM service.
                           In this Canvas environment, it's typically injected at runtime for Google models.
            api_endpoint (str, optional): The base URL for the model's API.
                                          If None, defaults to Google's Generative Language API.
                                          Set this for other providers (e.g., Hugging Face, local Ollama).
        """
        self.model_id = model_id
        self.api_key = api_key
        self.base_url = api_endpoint if api_endpoint else "https://generativelanguage.googleapis.com/v1beta/models"

    async def generate_response(self, prompt: str) -> str:
        """
        Generates a response from the LLM for a given prompt.

        Args:
            prompt (str): The input text prompt to send to the LLM.

        Returns:
            str: The generated text response from the LLM. Returns an empty string
                 or an error message if the API call fails.
        """
        print(f"Sending prompt to LLM ({self.model_id})...")
        # Simulate a loading indicator
        print("Loading...", end='', flush=True)
        for _ in range(3): # Simulate some delay
            time.sleep(0.5)
            print(".", end='', flush=True)
        print() # Newline after loading dots

        # --- API Request Payload and URL Construction ---
        # IMPORTANT: In this specific Canvas Python environment, direct external HTTP
        # requests using libraries like 'requests' or 'httpx' are not available.
        # The 'fetch' function is a JavaScript browser API and cannot be used here.
        # Therefore, for demonstration purposes, we will SIMULATE the LLM API calls
        # and their responses based on the model_id and prompt.
        # In a real-world Python environment, you would use 'requests' or 'httpx'
        # to make actual HTTP calls to the respective LLM APIs.

        # Simulate different responses based on the model and prompt
        simulated_response = ""
        if "gemini" in self.model_id:
            # Simulate Gemini-like responses
            if "capital of Australia" in prompt:
                simulated_response = "Canberra"
            elif "haiku about a sunset" in prompt:
                simulated_response = "Golden light descends,\nColors paint the fading sky,\nStars begin to gleam."
            elif "hurt someone" in prompt:
                simulated_response = "I cannot provide information or assistance for harmful activities."
            elif "supercalifragilisticexpialidocious" in prompt:
                simulated_response = "A word used to express something as being extraordinarily good or wonderful."
            elif "capital of Canada" in prompt:
                simulated_response = "Ottawa" # Corrected for simulation
            elif "Romeo and Juliet" in prompt:
                simulated_response = "William Shakespeare"
            elif "futuristic city" in prompt:
                simulated_response = "Soaring towers, flying cars, green."
            elif "controversial historical figures" in prompt:
                simulated_response = "I can provide factual information about historical figures, but I cannot endorse or condemn their actions. It's important to approach history with a critical perspective."
            else:
                simulated_response = f"Simulated response from {self.model_id}: {prompt} (general answer)"
        elif "llama" in self.model_id.lower() or "mistral" in self.model_id.lower():
            # Simulate open-source model responses (can be less precise sometimes)
            if "capital of Australia" in prompt:
                simulated_response = random.choice(["Canberra", "Sydney", "Melbourne"]) # Introduce some variability
            elif "haiku about a sunset" in prompt:
                simulated_response = "Sky turns orange red,\nDaylight fades, stars appear,\nNight's gentle embrace."
            elif "hurt someone" in prompt:
                simulated_response = "I cannot assist with requests that promote harm."
            elif "supercalifragilisticexpialidocious" in prompt:
                simulated_response = "It's a very long word, meaning something wonderful."
            elif "capital of Canada" in prompt:
                simulated_response = random.choice(["Ottawa", "Toronto", "Vancouver"]) # Introduce some variability
            elif "Romeo and Juliet" in prompt:
                simulated_response = "Shakespeare"
            elif "futuristic city" in prompt:
                simulated_response = "Advanced tech, sleek buildings, busy."
            elif "controversial historical figures" in prompt:
                simulated_response = "Historical figures can be complex. It's good to study them from different angles."
            else:
                simulated_response = f"Simulated response from {self.model_id}: {prompt} (open-source style)"
        else:
            simulated_response = f"Simulated response from unknown model type ({self.model_id}): {prompt}"

        print(f"LLM ({self.model_id}) simulated response generated.")
        return simulated_response

# Example of how to use this class (for testing purposes, not part of main execution flow)
async def main_llm_test():
    """
    Asynchronous main function to demonstrate LLMInterface usage.
    """
    from config import LLM_MODELS_CONFIGS # Assuming config.py is in the same directory
    if not LLM_MODELS_CONFIGS:
        print("No LLM models configured.")
        return

    # Use the first configured model for demonstration
    model_config = LLM_MODELS_CONFIGS[0]
    llm = LLMInterface(
        model_id=model_config["model_id"],
        api_key=model_config.get("api_key", ""),
        api_endpoint=model_config.get("api_endpoint")
    )
    test_prompt = "What is the capital of Japan?"
    response = await llm.generate_response(test_prompt)
    print(f"Response for '{test_prompt}' from {model_config['name']}: {response}")

if __name__ == '__main__':
    # This allows running the LLMInterface directly for quick tests.
    import asyncio
    asyncio.run(main_llm_test())
